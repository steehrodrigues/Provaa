arqui=open("C:/Users/1700517/Desktop/Lista_IPs.txt","r")
DNS = arqui.readlines()
arqui.close()
arquivoValido = ""
arquivoInvalido = ""
for x in range (len(DNS)):
    DNS2 = DNS[x].rsplit(".")
    if (int(DNS2[0])<=255 and int(DNS2[1])<=255 and int(DNS2[2])<=255 and int(DNS2[3])<=255):
        arquivoValido += DNS[x] + "\n"
    else:
        arquivoInvalido += DNS[x] + "\n"

arquivo=open("C:/Users/1700517/Desktop/arquivoValido.txt","w")
arquivo.write(arquivoValido)
arquivo.close()

arquivo=open("C:/Users/1700517/Desktop/arquivoInvalido.txt","w")
arquivo.write(arquivoInvalido)
arquivo.close()

print ("Seu arquivo foi concluido")
